#include <iostream>
#include <fstream>
#include <string.h>
#include <stdlib.h>
#include <vector>
#include <boost/program_options/options_description.hpp>
#include <boost/program_options/variables_map.hpp>
#include <boost/program_options/parsers.hpp>
#include <Eigen/Dense>
#include <Eigen/SVD>
#include "exceptions.cpp"

namespace eg = Eigen;

bool WritePoints(std::string filename, eg::Matrix<float, 4, 4> pts){
  std::ofstream outfile;
  outfile.open(filename.c_str());
  if(outfile.is_open() == false){
    throw PBRegException("Error opening or creating file: " + filename);
  }
  try{
    const int cols = 4;
    const int rows = 4;
    for(int row=0; row<rows; ++row){
      for(int col=0; col<cols; ++col){
        outfile << pts(row, col) << " ";
      }
      outfile << "\n";
    }
    outfile.close();
  } catch (std::exception &ex){
    throw PBRegException("Error writing to file: " + filename);
  }
  return true;
}

eg::Matrix<float, eg::Dynamic, 3> ReadPoints(std::string filename){
  std::ifstream afile;
  std::vector< std::vector<float> > result;
  std::vector<float> x_vec;
  std::vector<float> y_vec;
  std::vector<float> z_vec;
  float x;
  afile.open(filename.c_str());
  if(afile.is_open() == false){
    throw PBRegException("File not found: " + filename);
  }
  try{
    int r = 0;
    while(afile >> x){
      if(r == 0){
        x_vec.push_back(x);
      } else if(r == 1){
        y_vec.push_back(x);
      } else {
        z_vec.push_back(x);
        r = -1;
      }
      r++;
    }
    result.push_back(x_vec);
    result.push_back(y_vec);
    result.push_back(z_vec);
    int rows = x_vec.size();
    eg::Matrix<float, eg::Dynamic, 3> result_matrix;
    result_matrix.resize(rows, 3);
    for(int i=0; i<rows; i++){
      for(int j=0; j<3; j++){
        result_matrix(i, j) =  result[j][i];
      }
    }
    return result_matrix;
  } catch(std::exception &ex){
    throw PBRegException("Error reading data from input file. Terminating.");
  }
}

eg::Matrix<float, 1, 3> FindCentroid(eg::Matrix<float, eg::Dynamic, 3> p){
  eg::Matrix<float, 1, 3> result;
  int rows = p.rows();
  float x_res = 0.0f;
  float y_res = 0.0f;
  float z_res = 0.0f;
  for(int idx=0; idx<rows; ++idx){
    x_res += p(idx, 0);
    z_res += p(idx, 1);
    y_res += p(idx, 2);
  }
  result(0, 0) = x_res/rows;
  result(0, 1) = z_res/rows;
  result(0, 2) = y_res/rows;
  return result;
}


float SSD(eg::Matrix<float, eg::Dynamic, 3> fixed_pts,
          eg::Matrix<float, eg::Dynamic, 3> moving_pts,
          eg::Matrix<float, 4, 4> A){
  float sq = 0.0f;
  eg::Matrix<float, 3, 3> R = A.block(0, 0, 3, 3);
  eg::Matrix<float, 3, 1> T = A.block(0, 3, 3, 1);
  for(int n=0; n<fixed_pts.rows(); ++n){
    eg::Matrix<float, 3, 1> difference = fixed_pts.transpose().col(n) -
      (R*moving_pts.transpose().col(n) + T);
    sq += difference.squaredNorm();
  }
  return sq;
}

eg::Matrix<float, 4, 4> PBReg(eg::Matrix<float, eg::Dynamic, 3> fixed_pts,
                            eg::Matrix<float, eg::Dynamic, 3> moving_pts){
  eg::Matrix<float, 4, 4> result;
  result(3, 0) = 0;
  result(3, 1) = 0;
  result(3, 2) = 0;
  result(3, 3) = 1;
  eg::Matrix<float, 1, 3> fixed_centroid = FindCentroid(fixed_pts);
  eg::Matrix<float, 1, 3> moving_centroid = FindCentroid(moving_pts);

  eg::Matrix<float, eg::Dynamic, 3> fixed_q;
  eg::Matrix<float, eg::Dynamic, 3> moving_q;

  fixed_q.resize(fixed_pts.rows(), 3);
  moving_q.resize(moving_pts.rows(), 3);

  for(int i=0; i<fixed_pts.rows(); ++i){
    fixed_q.row(i) = fixed_pts.row(i) - fixed_centroid;
    moving_q.row(i) = moving_pts.row(i) - moving_centroid;
  }

  eg::Matrix<float, 3, 3> H;
  H = eg::Matrix<float, 3, 3>::Zero(3, 3);
  for(int i=0; i<fixed_pts.rows(); ++i){
    eg::Matrix<float, 3, 3> h = fixed_q.transpose().col(i)*moving_q.row(i);
    H = H + h;
  }

  eg::JacobiSVD<eg::Matrix<float, 3, 3> > SVD(H, eg::ComputeFullU | eg::ComputeFullV);
  eg::Matrix<float, 3, 3> U = SVD.matrixU();
  eg::Matrix<float, 3, 3> V = SVD.matrixV();
  eg::Matrix<float, 3, 3> X = V*U.transpose();

  if(abs(X.determinant() - 1) < 1e-5){

  } else if(abs(X.determinant() + 1) < 1e-5) {
    std::cout << "Determinant = -1!\n";
    for(int i=0; i<3; ++i){
      const eg::VectorXf S = SVD.singularValues();
      if (abs(S(i)) < 1e-4){
        X = V*U.transpose();
        std::cout << "Success (reflection)!\n";
      }
    }
  } else {
    std::cout << "A bit lost here...\n";
  }

  X.transposeInPlace();

  eg::Matrix<float, 3, 1> T;

  T = fixed_centroid.transpose() - X*moving_centroid.transpose();

  for(int i=0; i<3; ++i){
    result(i, 3) = T(i, 0);
    for(int j=0; j<3; ++j){
      result(i, j) = X(i, j);
    }
  }

  return result;
}

eg::Matrix<float, 1, 3>FindClosestPoint(eg::Matrix<float, 1, 3> point,
                                        eg::Matrix<float, eg::Dynamic, 3> moving_pts){
  float MinNorm = (moving_pts.row(0) - point).norm();
  int MinNormIdx = 0;
  for(int idx=1; idx<moving_pts.rows(); ++idx){
    float Norm = (moving_pts.row(idx) - point).norm();
    if(Norm < MinNorm){
      MinNormIdx = idx;
      MinNorm = Norm;
    }
  }
  return moving_pts.row(MinNormIdx);
}

eg::Matrix<float, eg::Dynamic, 3>Transform(eg::Matrix<float, eg::Dynamic, 3> fixed_pts,
                                           eg::Matrix<float, 4, 4> A){
  eg::Matrix<float, eg::Dynamic, 3> result;
  eg::Matrix<float, 3, 3> R = A.block(0, 0, 3, 3);
  eg::Matrix<float, 3, 1> T = A.block(0, 3, 3, 1);
  result.resize(fixed_pts.rows(), 3);
  for(int idx=0; idx<fixed_pts.rows(); ++idx){
    eg::Matrix<float, 3, 1> transformed_pt;
    transformed_pt = R*fixed_pts.transpose().col(idx) + T;
    result.row(idx) = transformed_pt.transpose();
  }
  return result;
}


eg::Matrix<float, 4, 4>SBReg(eg::Matrix<float, eg::Dynamic, 3> fixed_pts,
                             eg::Matrix<float, eg::Dynamic, 3> moving_pts,
                             const int MaxIter){

  if(fixed_pts.rows() != moving_pts.rows()){
    throw PBRegException("Number of fixed points must be equal to the number of moving points. Terminating.");
  }

  if(fixed_pts.rows() < 3 || moving_pts.rows() < 3){
    throw PBRegException("Number of fixed and moving points must be greater or equal to three. Terminating.");
  }

  eg::Matrix<float, 4, 4> A = eg::Matrix<float, 4, 4>::Identity(4, 4);
  eg::Matrix<float, eg::Dynamic, 3> ClosestPts = fixed_pts;

  float OldSquaredDifference = SSD(fixed_pts, moving_pts, A);

  int n=0;
  while(n < MaxIter){
    std::cout << "SSD at iteration " << n << ": " << SSD(fixed_pts,
                                                         moving_pts, A)
                                                  << "\n";
    for(int idx=0; idx<ClosestPts.rows(); ++idx){
      eg::Matrix<float, eg::Dynamic, 3> TransformedPts = Transform(fixed_pts, A);
      ClosestPts.row(idx) = FindClosestPoint(fixed_pts.row(idx),
                                              TransformedPts);
    }
    eg::Matrix<float, 4, 4> B = PBReg(fixed_pts, moving_pts);
    float NewSquaredDifference = SSD(fixed_pts, moving_pts, B);
    if(NewSquaredDifference < OldSquaredDifference){
      A = B;
      OldSquaredDifference = NewSquaredDifference;
    } else {
      std::cout << "SSD at final iteration: " << SSD(fixed_pts,
                                                           moving_pts, A)
                                              << "\n";
      break;
    }
    n += 1;
  }
  return A;
}


int main(int argc, char *argv[]){

  namespace po = boost::program_options;

  bool UseSBReg = false;

  po::options_description description;
  description.add_options()
    ("help", "Produce help message")
    ("fixed", po::value<std::string>(), "Fixed points input file")
    ("moving", po::value<std::string>(), "Moving points input file")
    ("output", po::value<std::string>(), "Output file")
    ("sbreg", po::value<bool>(), "Use surface based registration?")
  ;

  boost::program_options::variables_map vm;
  po::store(parse_command_line(argc, argv, description), vm);
  po::notify(vm);

  eg::Matrix<float, eg::Dynamic, 3> moving_pts;
  eg::Matrix<float, eg::Dynamic, 3> fixed_pts;
  std::string output_filename;
  std::string fixed_filename;
  std::string moving_filename;

  if (vm.count("help")) {
    std::cout << description << "\n";
    return 1;
  }

  if (vm.count("fixed")){
    fixed_filename = vm["fixed"].as<std::string>();
  }

  if (vm.count("moving")){
    moving_filename = vm["moving"].as<std::string>();
  }

  if (vm.count("output")){
    output_filename = vm["output"].as<std::string>();
  }

  if(vm.count("sbreg")){
    UseSBReg = vm["sbreg"].as<bool>();
  }

  try{
    fixed_pts = ReadPoints(fixed_filename);
    moving_pts = ReadPoints(moving_filename);
  } catch (PBRegException &ex){
    std:: cout << ex.what() << ". Terminating.\n";
    return 1;
  } catch (po::invalid_command_line_syntax &ex){
    std::cout << "Program options exception:\n";
    std::cout << ex.what() << "\n";
    return 1;
  }

  std::cout << "Fixed points:  " << fixed_filename << "\n";
  std::cout << "Moving points: " << moving_filename << "\n";
  std::cout << "Output:        " << output_filename << "\n\n";

  eg::Matrix<float, 4, 4> ResultMatrix;
  try{
    if(UseSBReg == true){
      ResultMatrix = SBReg(fixed_pts, moving_pts, 100);
    } else {
      ResultMatrix = PBReg(fixed_pts, moving_pts);
    }
  } catch (PBRegException &ex){
    std::cout << ex.what() << "\n";
    return 1;
  }
  try{
    WritePoints(output_filename, ResultMatrix);
  } catch (PBRegException &ex){
    std::cout << ex.what() << "\n";
    return 1;
  }

  return 0;
}
