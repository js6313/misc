#include <string.h>
#include <iostream>


class PBRegException : public std::exception {
private:
  std::string msg;
public:
  PBRegException(const std::string s) : msg(s){}
  virtual ~PBRegException() throw(){};
  const char* what(){ return msg.c_str(); }
};
