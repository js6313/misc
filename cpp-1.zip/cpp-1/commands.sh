cd /home/jack/Desktop/cpp-1/PBReg-SuperBuild && rm * -r && cmake /home/jack/Desktop/cpp-1/PBReg && make && ./main --fixed "/home/jack/Desktop/cpp-1/PBReg/fran_cut_transformed.txt" --moving "/home/jack/Desktop/cpp-1/PBReg/fran_cut.txt" --output "/home/jack/Desktop/cpp-1/PBReg/output_2.txt" --sbreg true

